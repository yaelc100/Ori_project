package com.example.cohen.elfa17;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Test extends AppCompatActivity {
int check=9;
String Team1="Team one \n";
String Team2 ="team two\n";
TextView all, one,two;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        all=(TextView) findViewById(R.id.players);
        one=(TextView) findViewById(R.id.team1);
        two=(TextView) findViewById(R.id.team2);
    }

    public Item big(Item[] Plist,int n ) {
        Item[] plist1 = new Item[n];
        Item big=new Item("11", "big", 0);
        for (int x = 0; x <= n; x++) {
            plist1[x] =Plist[x];

        }
        for (int y=0; y <plist1.length; y++) {
            if (plist1[y].getDirug()>big.getDirug()) {
                big=plist1[y];
                
            }

        }
        return big;
    }

    public void scramble(View view) {

        Item[] itemlist=new Item[9];
        Item player1= new Item("1","alon", 7);
        Item player2= new Item("2","ori", 9);
        Item player3= new Item("3","roee", 6);
        Item player4= new Item("4","adi", 4);
        Item player5= new Item("5","ziv", 10);
        Item player6= new Item("6","yarin", 2);
        Item player7= new Item("7","lior", 5);
        Item player8= new Item("8","ron", 3);
        Item player9= new Item("9","avi", 1);
        Item player10= new Item("10","momi", 8);

        itemlist[0]= player1;
        itemlist[1]= player2;
        itemlist[2]= player3;
        itemlist[3]= player4;
        itemlist[4]= player5;
        itemlist[5]= player6;
        itemlist[6]= player7;
        itemlist[7]= player8;
        itemlist[8]= player9;
        itemlist[9]= player10;

        for(int i=0; i<itemlist.length; i++) {
            itemlist[check]=big(itemlist, check);
            check--;

        }
        for(int o=0;o<10; o++ ) {
            Team1=Team1+ itemlist[o].getName()+ "\n";
            o++;
            Team2= Team2+ itemlist[o].getName()+  "\n";
        }

         one.setText(Team1);
        two.setText(Team2);
    }

    public void bom(View view) {

    }
}
