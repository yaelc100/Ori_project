package com.example.cohen.elfa17;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Main extends AppCompatActivity {
EditText Name, Dirug;
ListView Reshima;
DatabaseReference ref;
List<Item> itemList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Name= (EditText) findViewById(R.id.Name);
        Dirug= (EditText) findViewById(R.id.dirug);
        Reshima= (ListView)findViewById(R.id.list);
        ref=FirebaseDatabase.getInstance().getReference("item1");

        itemList=new ArrayList<>();


    }

    @Override
    protected void onStart() {
        super.onStart();
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                itemList.clear();
                for (DataSnapshot itemsnapshot: dataSnapshot.getChildren())
                {
                    Item item= itemsnapshot.getValue(Item.class);
                    itemList.add(item);

                }
                Itemlist adapter=new Itemlist (Main.this, itemList);
                Reshima.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void push(View view) {
        String name1=Name.getText().toString();
        String dirug1=Dirug.getText().toString();
        int tikun=Integer.parseInt(dirug1);
        if ((!name1.isEmpty())&&(!dirug1.isEmpty())) {

            String id= ref.push().getKey();
            Item item = new Item(id, name1, tikun);
            ref.child(id).setValue(item);

        }
    }

    public void kuk(View view) {
        Intent t=new Intent(this, check.class);
       startActivity(t);
    }
}
